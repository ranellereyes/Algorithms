def well_formed?(str)

end
